const fs = require('fs');
const express = require('express');
const path = require('path');
const session = require('express-session');
const pool = require('./public/js/db'); // Import the MySQL connection pool
const app = express();
const PORT = 3000;

// Path configuration
const rootDir = __dirname;
const publicDir = path.join(rootDir, 'public');
const templatesDir = path.join(rootDir, 'templates');
const viewsDir = path.join(rootDir, 'views');

// Middleware
app.use(express.static(publicDir));
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(session({
    secret: 'your-secret-key',
    resave: false,
    saveUninitialized: true
}));

// Template renderer
async function renderPage(pageName, res) {
    try {
        const header = await fs.promises.readFile(path.join(templatesDir, 'header.html'), 'utf8');
        const content = await fs.promises.readFile(path.join(viewsDir, `${pageName}.html`), 'utf8');
        const footer = await fs.promises.readFile(path.join(templatesDir, 'footer.html'), 'utf8');
        res.send(header + content + footer);
    } catch (err) {
        console.error('Render error:', err);
        res.status(500).send('Page loading failed');
    }
}

// Routes
app.get('/', (req, res) => renderPage('home', res));
app.get('/create-account', (req, res) => renderPage('createAccount', res));
app.get('/give-away', (req, res) => renderPage('giveAwayPet', res));
app.get('/find', (req, res) => renderPage('findDogCat', res));
app.get('/dog-care', (req, res) => renderPage('dogCare', res));
app.get('/cat-care', (req, res) => renderPage('catCare', res));
app.get('/contact', (req, res) => renderPage('contactUs', res));
app.get('/privacy', (req, res) => renderPage('privacy', res));

// API Routes
app.post('/api/create-account', async (req, res) => {
    const { username, password } = req.body; // Removed email

    // Validate the input
    const validationError = validateCredentials(username, password);
    if (validationError) {
        return res.status(400).json({ message: validationError });
    }

    try {
        // Check if the username already exists
        const [rows] = await pool.execute('SELECT * FROM users WHERE username = ?', [username]);
        if (rows.length > 0) {
            return res.status(400).json({ message: 'Username is already taken.' });
        }

        // Insert the new user into the database (without email)
        await pool.execute('INSERT INTO users (username, password) VALUES (?, ?)', [username, password]);
        res.status(201).json({ message: 'Account successfully created!' });
    } catch (err) {
        console.error('Error during account creation:', err);
        res.status(500).json({ message: 'An error occurred. Please try again later.' });
    }
});
app.post('/api/login', async (req, res) => {
    const { username, password } = req.body;
    const validationError = validateCredentials(username, password);
    if (validationError) {
        return res.status(400).json({ message: validationError });
    }

    try {
        const [rows] = await pool.execute('SELECT * FROM users WHERE username = ? AND password = ?', [username, password]);
        if (rows.length > 0) {
            req.session.username = username;
            return res.status(200).json({ message: 'Login successful!' });
        }

        res.status(401).json({ message: 'Invalid username or password.' });
    } catch (err) {
        console.error('Error during login:', err);
        res.status(500).json({ message: 'An error occurred. Please try again later.' });
    }
});

app.post('/api/submit-pet', async (req, res) => {
    if (!req.session || !req.session.username) {
        return res.status(401).json({ message: 'You must log in to submit a pet.' });
    }

    const { animalType, breed, age, gender, getsAlongDogs, getsAlongCats, suitableForChildren, comments, ownerName, ownerEmail } = req.body;

    try {
        await pool.execute(
            `INSERT INTO pets (owner, pet_type, breed, age, gender, gets_along_dogs, gets_along_cats, suitable_for_children, comments, owner_name, owner_email)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
            [req.session.username, animalType, breed, age, gender, getsAlongDogs || false, getsAlongCats || false, suitableForChildren || false, comments || '', ownerName, ownerEmail]
        );

        res.status(201).json({ message: 'Pet successfully submitted!' });
    } catch (err) {
        console.error('Error handling pet submission:', err);
        res.status(500).json({ message: 'An error occurred. Please try again later.' });
    }
});

app.post('/api/find-pets', async (req, res) => {
    let { petType, breed, age, gender, otherDogs, otherCats, smallChildren } = req.body;

    // Set default values for checkboxes if they are undefined
    otherDogs = otherDogs === 'on' || otherDogs === true ? 1 : 0;
    otherCats = otherCats === 'on' || otherCats === true ? 1 : 0;
    smallChildren = smallChildren === 'on' || smallChildren === true ? 1 : 0;

    console.log('Received data:', { petType, breed, age, gender, otherDogs, otherCats, smallChildren }); // Debugging

    try {
        const query = `
            SELECT * FROM pets
            WHERE 
                (pet_type = ? OR ? IS NULL) AND
                (breed = ? OR ? = 'any') AND
                (age = ? OR ? = 'any') AND
                (gender = ? OR ? = 'any') AND
                (gets_along_dogs = ? OR ? IS NULL) AND
                (gets_along_cats = ? OR ? IS NULL) AND
                (suitable_for_children = ? OR ? IS NULL)
        `;
        const [rows] = await pool.execute(query, [
            petType, petType,
            breed, breed,
            age, age,
            gender, gender,
            otherDogs, otherDogs,
            otherCats, otherCats,
            smallChildren, smallChildren
        ]);

        let resultsHtml = '<h1>Matching Pets</h1>';
        if (rows.length > 0) {
            resultsHtml += '<ul>';
            rows.forEach(pet => {
                resultsHtml += `<li>${pet.pet_type} - Breed: ${pet.breed}, Age: ${pet.age}, Gender: ${pet.gender}</li>`;
            });
            resultsHtml += '</ul>';
        } else {
            resultsHtml += '<p>No pets match your criteria.</p>';
        }

        const header = await fs.promises.readFile(path.join(templatesDir, 'header.html'), 'utf8');
        const footer = await fs.promises.readFile(path.join(templatesDir, 'footer.html'), 'utf8');
        const fullHtml = header + resultsHtml + footer;

        res.send(fullHtml);
    } catch (err) {
        console.error('Error finding pets:', err); // Log the error
        res.status(500).send('An error occurred while finding pets.');
    }
});

// Logout Route
app.post('/api/logout', (req, res) => {
    console.log('Logout request received'); // Debugging

    if (req.session) {
        console.log('Session exists. Destroying session...'); // Debugging
        req.session.destroy(err => {
            if (err) {
                console.error('Error during logout:', err); // Log the error
                return res.status(500).json({ message: 'An error occurred while logging out. Please try again later.' });
            }
            console.log('Session destroyed successfully'); // Debugging
            res.status(200).json({ message: 'You have been logged out successfully.' });
        });
    } else {
        console.log('No active session found'); // Debugging
        res.status(400).json({ message: 'No active session found.' });
    }
});
// Helper Functions
function validateCredentials(username, password) {
    const usernameRegex = /^[a-zA-Z0-9]+$/;
    const passwordRegex = /^(?=.*[a-zA-Z])(?=.*\d)[a-zA-Z\d]{4,}$/;

    if (!usernameRegex.test(username)) {
        return 'Invalid username. Only letters and digits are allowed.';
    }
    if (!passwordRegex.test(password)) {
        return 'Invalid password. Must be at least 4 characters long, contain letters and digits, and have at least one letter and one digit.';
    }
    return null;
}

// Start Server
app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});

