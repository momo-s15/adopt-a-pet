-- Create the `users` table
CREATE TABLE users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(255) NOT NULL
);

-- Create the `pets` table
CREATE TABLE pets (
    id INT AUTO_INCREMENT PRIMARY KEY,
    owner VARCHAR(50) NOT NULL,
    pet_type VARCHAR(50) NOT NULL,
    breed VARCHAR(50) NOT NULL,
    age VARCHAR(50) NOT NULL,
    gender VARCHAR(10) NOT NULL,
    gets_along_dogs BOOLEAN NOT NULL DEFAULT FALSE,
    gets_along_cats BOOLEAN NOT NULL DEFAULT FALSE,
    suitable_for_children BOOLEAN NOT NULL DEFAULT FALSE,
    comments TEXT,
    owner_name VARCHAR(100),
    owner_email VARCHAR(100)
);