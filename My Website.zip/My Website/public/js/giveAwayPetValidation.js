document.getElementById('give-away-form').addEventListener('submit', async function (event) {
    event.preventDefault();

    // Remove existing error messages for the give-away form
    let errorContainer = document.querySelector('#give-away-form #error-message');
    if (errorContainer) {
        errorContainer.remove();
    }

    const animalType = document.getElementById('animalType').value;
    const breed = document.getElementById('breed').value.trim();
    const age = document.getElementById('age').value;
    const gender = document.getElementById('gender').value;
    const getsAlongDogs = document.getElementById('getsAlongDogs').checked;
    const getsAlongCats = document.getElementById('getsAlongCats').checked;
    const suitableForChildren = document.getElementById('suitableForChildren').checked;
    const comments = document.getElementById('comments').value.trim();
    const ownerName = document.getElementById('ownerName').value.trim();
    const ownerEmail = document.getElementById('ownerEmail').value.trim();

    let errorMessage = '';

    if (!animalType) {
        errorMessage += 'Please select an animal type.<br>';
    }
    if (!breed) {
        errorMessage += 'Please enter the breed.<br>';
    }
    if (!age) {
        errorMessage += 'Please select the age.<br>';
    }
    if (!gender) {
        errorMessage += 'Please select the gender.<br>';
    }
    if (!ownerName) {
        errorMessage += "Please enter the owner's full name.<br>";
    }
    if (!ownerEmail) {
        errorMessage += "Please enter the owner's email.<br>";
    } else if (!validateEmail(ownerEmail)) {
        errorMessage += 'Please enter a valid email address.<br>';
    }

    if (errorMessage) {
        const errorDiv = document.createElement('div');
        errorDiv.id = 'error-message';
        errorDiv.style.color = 'red';
        errorDiv.style.marginTop = '10px';
        errorDiv.innerHTML = errorMessage;
        document.getElementById('give-away-form').prepend(errorDiv);
    } else {
        // Prepare the data to send to the server
        const petData = {
            animalType,
            breed,
            age,
            gender,
            getsAlongDogs,
            getsAlongCats,
            suitableForChildren,
            comments,
            ownerName,
            ownerEmail,
        };

        try {
            // Send the data to the server
            const response = await fetch('/api/submit-pet', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify(petData),
            });

            const result = await response.json();

            if (response.ok) {
                alert(result.message);
                this.reset(); // Clear the form on success
            } else {
                alert(result.message || 'An error occurred. Please try again.');
            }
        } catch (err) {
            console.error('Error submitting form:', err);
            alert('An error occurred. Please try again later.');
        }
    }
});

function validateEmail(email) {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
}

document.getElementById('login-form').addEventListener('submit', async function (event) {
    event.preventDefault();

    const username = document.getElementById('username').value.trim();
    const password = document.getElementById('password').value.trim();

    try {
        const response = await fetch('/api/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ username, password }),
        });

        const result = await response.json();

        if (response.ok) {
            alert(result.message);
            document.getElementById('login-form').style.display = 'none';
            document.getElementById('pet-form-container').style.display = 'block';
        } else {
            alert(result.message || 'Login failed. Please try again.');
        }
    } catch (err) {
        console.error('Error during login:', err);
        alert('An error occurred. Please try again later.');
    }
});