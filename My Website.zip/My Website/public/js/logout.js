document.getElementById('logout-button').addEventListener('click', async () => {
    try {
        const response = await fetch('/api/logout', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
        });

        const result = await response.json();
        alert(result.message);

        if (response.ok) {
            // Redirect to the home page or login page after logout
            window.location.href = '/';
        }
    } catch (err) {
        console.error('Error during logout:', err);
        alert('An error occurred. Please try again later.');
    }
});