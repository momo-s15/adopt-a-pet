document.addEventListener("DOMContentLoaded", () => {
    const form = document.getElementById("create-account-form");
    const messageDiv = document.getElementById("message");

    form.addEventListener("submit", async (event) => {
        event.preventDefault();

        const username = document.getElementById("username").value.trim();
        const password = document.getElementById("password").value.trim();

        // Validate username
        const usernameRegex = /^[a-zA-Z0-9]+$/;
        if (!usernameRegex.test(username)) {
            messageDiv.textContent = "Invalid username. Only letters and digits are allowed.";
            return;
        }

        // Validate password
        const passwordRegex = /^(?=.*[a-zA-Z])(?=.*\d)[a-zA-Z\d]{4,}$/;
        if (!passwordRegex.test(password)) {
            messageDiv.textContent = "Invalid password. Must be at least 4 characters long, contain letters and digits, and have at least one letter and one digit.";
            return;
        }

        // Send data to the server
        try {
            const response = await fetch("/api/create-account", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                },
                body: JSON.stringify({ username, password }),
            });

            const result = await response.json();

            if (response.ok) {
                messageDiv.textContent = "Account successfully created! You can now log in.";
                form.reset();
            } else {
                messageDiv.textContent = result.message || "An error occurred. Please try again.";
            }
        } catch (error) {
            messageDiv.textContent = "Failed to connect to the server. Please try again later.";
        }
    });
});