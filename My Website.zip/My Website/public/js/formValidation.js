document.querySelector('form').addEventListener('submit', function(event) {
    event.preventDefault();

    const errorContainer = document.getElementById('error-message');
    if (errorContainer) {
        errorContainer.remove();
    }

    const petType = document.getElementById('petType').value;

    const breed = document.getElementById('breed').value;

    const age = document.getElementById('age').value;

    const gender = document.getElementById('gender').value;

    let errorMessage = '';

    if (!petType) {
        errorMessage += 'Please select a pet type.<br>';
    }
    if (!breed) {
        errorMessage += 'Please select a breed.<br>';
    }
    if (!age) {
        errorMessage += 'Please select a preferred age.<br>';
    }
    if (!gender) {
        errorMessage += 'Please select a preferred gender.<br>';
    }

    
    const checkboxes = document.querySelectorAll('fieldset input[type="checkbox"]');
    const anyChecked = Array.from(checkboxes).some(checkbox => checkbox.checked);

    if (!anyChecked) {
        errorMessage += 'Please select at least one option for "Must get along with".<br>';
    }

    if (errorMessage) {
        const errorDiv = document.createElement('div');
        errorDiv.id = 'error-message';
        errorDiv.style.color = 'red';
        errorDiv.style.marginTop = '10px';
        errorDiv.innerHTML = errorMessage;
        document.querySelector('form').prepend(errorDiv);
    } else {

        alert('Form submitted successfully!');
        this.submit();
    }
});



// Form validation for create account
document.getElementById('registrationForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    
    // Client-side validation
    if (!/^[a-zA-Z0-9]+$/.test(username)) {
        alert('Username can only contain letters and digits');
        return;
    }
    
    if (password.length < 4 || !/[a-zA-Z]/.test(password) || !/[0-9]/.test(password)) {
        alert('Password must be at least 4 characters with at least one letter and one digit');
        return;
    }
    
    try {
        const response = await fetch('/api/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        
        const result = await response.json();
        if (response.ok) {
            alert('Account created successfully! You can now log in.');
            window.location.href = '/giveAwayPet';
        } else {
            alert(result.error);
        }
    } catch (error) {
        alert('Error connecting to server');
    }
});