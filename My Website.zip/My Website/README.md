## Adopt a Cat/Dog Website 🐾

### Overview
The **Adopt a Cat/Dog Website** is a full-stack web application designed to connect pet lovers with pets in need of a home. The platform allows users to create accounts, log in, and perform various actions such as submitting pets for adoption, searching for pets based on specific criteria, and learning about pet care. This project demonstrates skills in backend development, database management, and frontend integration, making it a great showcase for aspiring developers.

---

### Features
- **User Authentication**:
  - Secure account creation and login functionality.
  - Session management using `express-session`.

- **Pet Submission**:
  - Logged-in users can submit pets for adoption with details such as type, breed, age, gender, and compatibility with other pets or children.

- **Pet Search**:
  - Users can search for pets based on criteria like type, breed, age, gender, and compatibility.
  - Results are dynamically displayed with matching pets.

- **Pet Care Information**:
  - Dedicated pages for dog and cat care tips.

- **Logout Functionality**:
  - Securely destroys user sessions to log out.

---

### Technologies Used
- **Backend**:
  - Node.js with Express.js for server-side logic.
  - MySQL for database management.
  - `mysql2` for database queries.
  - `express-session` for session handling.

- **Frontend**:
  - HTML, CSS, and JavaScript for responsive and user-friendly interfaces.

- **Other Tools**:
  - File system operations using Node.js `fs` module.
  - Dynamic HTML rendering with templates.

---

### Database Schema
The application uses two main tables:
1. **Users**:
   - Stores user credentials (`username`, `password`).
2. **Pets**:
   - Stores pet details (`type`, `breed`, `age`, `gender`, compatibility flags, and owner information).

---

### How to Run
1. Clone the repository:
   ```bash
   git clone https://github.com/your-username/adopt-a-pet.git
   ```
2. Install dependencies:
   ```bash
   npm install
   ```
3. Set up the database:
   - Create a MySQL database and run the `schema.sql` file to create the necessary tables.
4. Start the server:
   ```bash
   node server.js
   ```
5. Open the application in your browser at `http://localhost:3000`.

---

### Why This Project?
This project showcases my ability to build a complete web application from scratch, including:
- Designing and implementing a relational database.
- Writing secure and efficient backend code.
- Creating a user-friendly frontend interface.
- Handling real-world scenarios like session management and error handling.

---

### Future Enhancements
- Add password hashing for enhanced security.
- Implement email notifications for account creation and pet submissions.
- Add an admin panel for managing users and pets.

